import React from 'react';

const About = () =>{
    return (<div>
        <h1>About Us:</h1>
        <p>We specialize in great products and services</p>
    </div>)
}
export default About;